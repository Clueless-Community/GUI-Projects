<a href="#"><img width="100%" height="auto" src="https://github.com/RuchikaSuryawanshi7/Webgenix/blob/main/images/code.jpg" height="50px"/></a>

<h1 align="center">Hi <img src="https://raw.githubusercontent.com/MartinHeinz/MartinHeinz/master/wave.gif" width="30px">, I'm Ruchika Suryawasnhi</h1>
<h3 align="center">I'm a passionate Researcher and Developer</h3>


## 🙋‍♂️ About Me

- 🌱 I’m currently learning **Data Structures and Algorithms.**

- 📫 How to reach me **ruchikasuryawanshi710@gmail.com**

## 🚀 Languages and Tools:

<p align="left"> 
    <a href="https://www.java.com" target="_blank"> <img src="https://img.icons8.com/color/48/000000/java-coffee-cup-logo.png"/> </a>
    <a href="https://reactjs.org/" target="_blank"> <img src="https://img.icons8.com/color/48/000000/react-native.png"/> </a>
    <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank"> <img src="https://img.icons8.com/color/48/000000/javascript.png"/> </a> 
    <a href="https://www.w3.org/html/" target="_blank"> <img src="https://img.icons8.com/color/48/000000/html-5.png"/> </a> 
    <a href="https://www.w3schools.com/css/" target="_blank"> <img src="https://img.icons8.com/color/48/000000/css3.png"/> </a> 
    <a href="https://www.w3schools.com/sass/" target="_blank"> <img src="https://img.icons8.com/ios/50/000000/sass.png"/> </a> 
    <a href="https://getbootstrap.com" target="_blank"> <img src="https://img.icons8.com/color/48/000000/bootstrap.png"/> </a> 
    <a style="padding-right:8px;" href="https://nodejs.org" target="_blank"> <img src="https://img.icons8.com/color/48/000000/nodejs.png"/> </a> 
    <a href="https://firebase.google.com/" target="_blank"> <img src="https://img.icons8.com/color/48/000000/firebase.png"/> </a> 
    <a href="https://postman.com" target="_blank"> <img src="https://www.vectorlogo.zone/logos/getpostman/getpostman-icon.svg" alt="postman" width="45" height="45"/> </a>   
    <a href="https://redux.js.org" target="_blank"> <img src="https://img.icons8.com/color/48/000000/redux.png"/> </a>
    <a href="https://www.typescriptlang.org/" target="_blank"> <img src="https://img.icons8.com/color/48/000000/typescript.png"/> </a>
    <a href="https://code.visualstudio.com/" target="_blank"> <img src="https://img.icons8.com/color/48/000000/visual-studio-code-2019.png"/> </a>
    <a href="https://www.jetbrains.com/idea/" target="_blank">    <img src="https://img.icons8.com/color/48/000000/intellij-idea.png"/> </a>
    <a href="https://www.eclipse.org/" target="_blank"><img src="https://img.icons8.com/officel/48/000000/java-eclipse.png"/></a>
    <a href="https://www.sublimetext.com/" target="_blank"><img src="https://img.icons8.com/fluency/48/000000/sublime-text.png"/> </a>
    <a href="https://git-scm.com/" target="_blank">  <img src="https://img.icons8.com/color/48/000000/git.png"/></a>
    <a href="https://figma.com" target="_blank">  <img src="https://img.icons8.com/color/48/000000/figma--v1.png"/></a>
   
  
</p>

<br/>

<p align="center">
    <a href="https://github.com/RuchikaSuryawanshi7/github-readme-streak-stats">
        <img title="🔥 Get streak stats for your profile at git.io/streak-stats" alt="Ruchika Suryawanshi's streak" src="https://github-readme-streak-stats.herokuapp.com/?user=RuchikaSuryawanshi7&theme=black-ice&hide_border=true&stroke=0000&background=060A0CD0"/>
    </a>
</p>

## 📊 My Github Stats

  <br/>
    <a href="https://github.com/RuchikaSuryawanshi7/github-readme-stats"><img alt="Ruchika Suryawanshi's Github Stats" src="https://github-readme-stats.vercel.app/api?username=RuchikaSuryawanshi7&show_icons=true&count_private=true&theme=react&hide_border=true&bg_color=0D1117" /></a>
  <a href="https://github.com/RuchikaSuryawanshi7/github-readme-stats"><img alt="Ruchika Suryawanshi's Top Languages" src="https://github-readme-stats.vercel.app/api/top-langs/?username=RuchikaSuryawanshi7&langs_count=8&count_private=true&layout=compact&theme=react&hide_border=true&bg_color=0D1117" /></a>
  <br/>
<!--   <b>Note:</b> Top languages is only a metric of the languages my public code consists of and doesn't reflect experience or skill level.
 -->

<br/>
<br/>

<a href="https://github.com/RuchikaSuryawanshi7/github-readme-activity-graph"><img alt="Ruchika Suryawanshi's Activity Graph" src="https://activity-graph.herokuapp.com/graph?username=RuchikaSuryawanshi7&bg_color=0D1117&color=5BCDEC&line=5BCDEC&point=FFFFFF&hide_border=true" /></a>

<br/>
<br/>

## Connect with me:
<p align="left">

<a href = "https://www.linkedin.com/in/ruchika-suryawanshi/"><img src="https://img.icons8.com/fluent/48/000000/linkedin.png"/></a>
<a href = "https://www.instagram.com/danzatrice7/"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"/></a>
    
</p>

## ❤ Views
   ![](https://github.com/RuchikaSuryawanshi7)


